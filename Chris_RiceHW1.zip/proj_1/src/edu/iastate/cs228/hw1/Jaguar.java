package edu.iastate.cs228.hw1;

/**
 *  
 * @author Chris Rice
 *
 */

/**
 * A jaguar eats a deer and competes against a puma. 
 */
public class Jaguar extends Animal
{
	/**
	 * Constructor 
	 * @param j: jungle
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	public Jaguar (Jungle j, int r, int c, int a) 
	{
		this.jungle=j;
		this.row=r;
		this.column=c;
		this.age=a;
	}
	
	/**
	 * A jaguar occupies the square. 	 
	 */
	public State who()
	{
		return State.JAGUAR;
	}
	
	/**
	 * A jaguar dies of old age or hunger, from isolation and attack by more numerous pumas.
	 *  
	 * @param jNew     jungle in the next cycle
	 * @return Living  life form occupying the square in the next cycle. 
	 */
	
	public Living next(Jungle jNew)
	{
		int population[]= new int[5];
		this.census(population);
		if(age==5) {
			Living r = new Empty(jNew,row,column);
			return r;
		}
		if(population[3]*2<=population[4]) {
			Living r = new Puma(jNew,row,column,0);
			return r;
		}
		if(population[3]+population[4]>population[0]) {
			Living r = new Empty(jNew,row,column);
			return r;
		}
		Living r = new Jaguar(jNew,row,column,age+1);
		return r;
		
		// See Living.java for an outline of the function. 
		// See Section 2.1 in the project description for the survival rules for a jaguar. 
	}
}
