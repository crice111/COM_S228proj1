package edu.iastate.cs228.hw1;


/**
 * 
 * Different forms of life. 
 *
 */
public enum State 
{
	DEER, EMPTY, GRASS, JAGUAR, PUMA 
}

